/*:
 * @target MZ
 * @plugindesc ====== GERENCIADOR GERAL ======
 * @author Necromante96Official & GitHub Copilot
 * 
 */
 