/*:
 * @target MZ
 * @plugindesc ====== TELA DE TITÚLO ======
 * @author Necromante96Official & GitHub Copilot
 * 
 */
